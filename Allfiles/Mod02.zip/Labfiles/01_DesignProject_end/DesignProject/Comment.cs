﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignProject
{
    public class Comment
    {
        public int CommentID
        {
            get => default(int);
            set
            {
            }
        }

        public int User
        {
            get => default(int);
            set
            {
            }
        }

        public string Owner
        {
            get => default(string);
            set
            {
            }
        }

        public string Subject
        {
            get => default(string);
            set
            {
            }
        }

        public string Body
        {
            get => default(string);
            set
            {
            }
        }

        public int PhotoID
        {
            get => default(int);
            set
            {
            }
        }
    }
}